import { Component, input, output, ViewChild } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { ExpenseLedger, Expense, ExpenseAdd, ExpenseUpdate } from '../expense-ledger/expense-ledger';

@Component({
  selector: 'app-cost-popup',
  standalone: true,
  imports: [LucideAngularModule, ExpenseLedger],
  templateUrl: './cost-popup.html',
  styleUrls: ['./cost-popup.css'],
})
export class CostPopup {
  expenses      = input.required<Expense[]>();
  addExpense    = output<ExpenseAdd>();
  updateExpense = output<ExpenseUpdate>();
  deleteExpense = output<number | string>();
  close         = output<void>();

  @ViewChild('ledgerRef') ledgerRef!: ExpenseLedger;
}
