// popup-host.service.ts
import { Injectable, ApplicationRef, createComponent, EnvironmentInjector, ComponentRef } from '@angular/core';
import { CostPopup } from './cost-popup';
import { ExpenseAdd, ExpenseUpdate, Expense } from '../expense-ledger/expense-ledger';

@Injectable({ providedIn: 'root' })
export class PopupHostService {
  private ref?: ComponentRef<CostPopup>;

  constructor(
    private appRef: ApplicationRef,
    private injector: EnvironmentInjector
  ) {}

  open(config: {
    expenses: Expense[];
    position: { top: number; left: number };
    onAdd: (e: ExpenseAdd) => void;
    onUpdate: (e: ExpenseUpdate) => void;
    onDelete: (id: number | string) => void;
  }) {
    this.close();

    const ref = createComponent(CostPopup, { environmentInjector: this.injector });

    // Set inputs
    ref.setInput('expenses', config.expenses);

    // Set position styles directly on host element
    const el = ref.location.nativeElement as HTMLElement;
    el.style.position = 'fixed';
    el.style.top = config.position.top + 'px';
    el.style.left = config.position.left + 'px';
    el.style.transform = 'translateX(-50%)';
    el.style.zIndex = '9999';

    el.setAttribute('data-cost-popup', '');

    // Wire outputs
    ref.instance.addExpense.subscribe(config.onAdd);
    ref.instance.updateExpense.subscribe(config.onUpdate);
    ref.instance.deleteExpense.subscribe(config.onDelete);
    ref.instance.close.subscribe(() => this.close());

    this.appRef.attachView(ref.hostView);
    document.body.appendChild(el);
    this.ref = ref;

    console.log('popup el appended to body:', el);
    console.log('body contains popup:', document.body.contains(el));
  }

  close() {
    if (this.ref) {
      this.appRef.detachView(this.ref.hostView);
      this.ref.destroy();
      this.ref = undefined;
    }
  }

  isOpen(): boolean {
    return !!this.ref;
  }
}
