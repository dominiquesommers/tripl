import { Component, input, output, signal, computed } from '@angular/core';
import { DatePipe } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';

export interface Expense {
  id: number | string;
  amount: number;
  date: string;        // ISO date string e.g. '2026-04-24'
  details: string | null;
}

export interface ExpenseAdd {
  amount: number;
  date: string;
  details: string | null;
}

export interface ExpenseUpdate {
  id: number | string;
  amount: number;
  date: string;
  details: string | null;
}

@Component({
  selector: 'app-expense-ledger',
  standalone: true,
  imports: [LucideAngularModule, DatePipe],
  templateUrl: './expense-ledger.html',
  styleUrls: ['./expense-ledger.css'],
})
export class ExpenseLedger {

  // ─── Inputs ───────────────────────────────────────────────
  expenses = input.required<Expense[]>();

  // ─── Outputs ──────────────────────────────────────────────
  addExpense    = output<ExpenseAdd>();
  updateExpense = output<ExpenseUpdate>();
  deleteExpense = output<number | string>();

  // ─── Add form state ───────────────────────────────────────
  isAdding  = signal(false);
  newDate    = signal(this.todayISO());
  newAmount  = signal<number | null>(null);
  newDetails = signal<string | null>(null);

  // ─── Edit state ───────────────────────────────────────────
  editingId  = signal<number | string | null>(null);
  editDate    = signal('');
  editAmount  = signal<number>(0);
  editDetails = signal<string | null>(null);

  // ─── Helpers ──────────────────────────────────────────────
  todayISO(): string {
    return new Date().toISOString().split('T')[0];
  }

  startEdit(exp: Expense) {
    this.editingId.set(exp.id);
    this.editDate.set(exp.date);
    this.editAmount.set(exp.amount);
    this.editDetails.set(exp.details);
  }

  confirmEdit(exp: Expense) {
    const amount = this.editAmount();
    if (!amount) return;
    this.updateExpense.emit({
      id: exp.id,
      amount,
      date: this.editDate(),
      details: this.editDetails(),
    });
    this.editingId.set(null);
  }

  confirmAdd() {
    const amount = this.newAmount();
    if (!amount) return;
    this.addExpense.emit({
      amount,
      date: this.newDate(),
      details: this.newDetails(),
    });
    // Reset form
    this.isAdding.set(false);
    this.newAmount.set(null);
    this.newDetails.set(null);
    this.newDate.set(this.todayISO());
  }

  onDelete(exp: Expense, event: MouseEvent) {
    event.stopPropagation();
    this.deleteExpense.emit(exp.id);
  }
}
