import {
  Component, input, output, signal, computed,
  ElementRef, ViewChild, HostListener
} from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { CostBadge } from '../cost-badge/cost-badge';
import { CostPopup } from '../cost-popup/cost-popup';
import { Expense, ExpenseAdd, ExpenseUpdate } from '../expense-ledger/expense-ledger';
import {PopupHostService} from '../cost-popup/cost-popup.service';

@Component({
  selector: 'app-cost',
  standalone: true,
  imports: [LucideAngularModule, CostBadge],
  templateUrl: './cost.html',
  styleUrls: ['./cost.css'],
})
export class Cost {

  // ─── Inputs ───────────────────────────────────────────────
  estimatedCost     = input.required<number>();
  actualTotal   = input<number | null>(null);
  isPaid            = input.required<boolean>();
  expenses        = input.required<Expense[]>();
  note           = input<string | null>(null);
  referenceUrl   = input<string | null>(null);
  label          = input<string | null>(null);
  mode      = input<'simple' | 'tracked'>('tracked');
  iconName       = input<string | null>(null);
  iconColor          = input<string>('#f1c40f');
  step              = input<number>(1);
  min               = input<number>(0);

  // ─── Outputs ──────────────────────────────────────────────
  saveEstimated    = output<number>();
  saveActual       = output<number | null>();
  togglePaid       = output<boolean>();
  addExpense       = output<ExpenseAdd>();
  updateExpense    = output<ExpenseUpdate>();
  deleteExpense    = output<number | string>();
  saveNote         = output<string | null>();
  saveReferenceUrl = output<string | null>();

  // ─── Popup state ──────────────────────────────────────────
  popupOpen     = signal(false);
  popupPosition = signal<{ top: number; left: number } | null>(null);

  // ─── Derived values ───────────────────────────────────────
  paidAmount = computed(() =>
    this.expenses().reduce((sum, e) => sum + e.amount, 0)
  );

  // ─── Refs ─────────────────────────────────────────────────
  @ViewChild(CostPopup, { read: ElementRef }) popupElRef?: ElementRef;

  constructor(private elRef: ElementRef, private popupHost: PopupHostService) {}

  // ─── Outside click ────────────────────────────────────────
  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as Node;
    const insideBadge = this.elRef.nativeElement.contains(target);
    const clickedInsidePopup = !!(event.target as HTMLElement).closest('[data-cost-popup]');
    if (!insideBadge && !clickedInsidePopup && this.popupHost.isOpen()) {
      this.popupHost.close();
    }
  }

  // ─── Handlers ─────────────────────────────────────────────
  onOpenDetails() {
    const rect = this.elRef.nativeElement.getBoundingClientRect();
    this.popupHost.open({
      expenses: this.expenses(),
      position: { top: rect.bottom + 8, left: rect.left + rect.width / 2 },
      onAdd: (e) => this.addExpense.emit(e),
      onUpdate: (e) => this.updateExpense.emit(e),
      onDelete: (id) => this.deleteExpense.emit(id),
    });
  }

  onClosePopup() {
    this.popupHost.close();
  }
}
